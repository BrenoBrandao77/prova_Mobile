import  React,{useState} from 'react';
import { Text, View, StyleSheet, Image, TouchableOpacity, StatusBar } from 'react-native';
import Mod from './prova/estilos/estilos'
export default function App() {
  const [img, setImg] = useState(require('./prova/prova/assets/popped_balloon_green.jpg'));
  const [textoFrase, setTextoFrase] = useState('');
  let frases = [
    'BATE',
    'DANCA DE LADIN',
    'BATE BATE',
    'QUEBRA DE LADIN',
    
  ];

  function quebrar() {
    let numeroAleatorio = Math.floor(Math.random() * frases.length);
    setTextoFrase(frases[numeroAleatorio]);
    setImg(require('./prova/prova/assets/popped_balloon_green.jpg'));
  }

  function reiniciar() {
    setImg(require('./prova/prova/assets/balloon_green.jpg'));
    setTextoFrase('');
  }

  return (
    <View style={Mod.container}>
      <Image style={{ width: 280, height: 580 }} source={img} />
      <Text style={Mod.text}>{textoFrase ? `"${textoFrase}"` : ''}</Text>
      <TouchableOpacity onPress={quebrar}>
        <View style={Mod.btnArea}>
          <Text style={Mod.btnTexto}>DESENROLA</Text>
        </View>
      </TouchableOpacity>

      <TouchableOpacity onPress={reiniciar}>
        <View style={[Mod.btnArea, { marginTop: 22, borderColor: 'black' }]}>
          <Text style={[Mod.btnTexto, { color: 'black' }]}>Reiniciar</Text>
        </View>
      </TouchableOpacity>
      <StatusBar style="auto" />
    </View>
  );
}

