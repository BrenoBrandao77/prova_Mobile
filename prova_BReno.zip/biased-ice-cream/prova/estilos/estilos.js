import {StyleSheet} from 'react-native'

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',

  },
  text: {
    fontSize: 30,
    color: '#8B8B7A',
    margin: 34,
    fontStyle: 'calibri',
    textAlign: 'center',
    backgroundColor: '#7FFF00'


  },

  btnArea: {
    width: 300,
    height: 22,
    borderRadius: 23,
    borderColor: 'blue',
    backgroundColor: '#AFEEEE',
    borderWidth: 7,
    padding: 32,
    alignItems: 'center',
    justifyContent: 'center',

  },

  btnTexto: {
    color: 'red',
    fontSize: 25,
    fontStyle: 'calibri',
   
  },
});

export default styles;